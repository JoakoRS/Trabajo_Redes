import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author RODRIGO
 */
class NewClass {
// función cuya intención es hallar el vértice indicado con la mínima distancia 
    int menor_distancia(int dis[],boolean recorrido[],int a){
        //declarar el mayor valor 
        int minimo=Integer.MAX_VALUE;
        int menor_index=-1;
        for (int i = 0; i < a; i++) {
            //Recorrido de nodos que ya estén procesados 
            if (recorrido[i]==false && dis[i]<=minimo) {
                /* De darse un valor falso, o que no ha sido analizado
                se delvuelve el menor valor*/
                minimo=dis[i];
                menor_index= i;
            }
        }
        
        return menor_index;
        
    }
    //Función para imprimir las distancias de recorrido
    void ImprimirCamino(int dis[],int a,int source){
        
         System.out.println("");
        System.out.println("╒▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬╗");
        System.out.println("Distancias mínimas desde origen: "+ source);
        System.out.println("╘▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬╝");
        System.out.println("Vértice \t Distancia desde el origen");
        for (int i = 0; i < a; i++) {
            System.out.println("  "+(i) + "\t\t\t" + dis[i]);
        }
    }
      
    /* Función Dijkstra , se ejecutará para hallar el minimo recorrido dada la matriz de 
    adyacencia de un grafo*/  
    
    void alg_dijkstra(int grafo[][],int source){
        
        int b = grafo[0].length;
        int dis[] = new int[b];
        /* El arreglo dis[] es el que almacena las menores distancias del
    origen a cada vértice que se procese  y le asignará el valor true para que sea incluido en el arreglo de la solución */
        boolean process[]= new boolean[b];
        // Declarar distancias hacia el infinito y el proceso como falso
        for (int i = 0; i < b; i++) {
            dis[i]=Integer.MAX_VALUE;
            process[i]=false;
        }
        // Distancia de origen a origen será 0 
               dis[source]=0;
        // Encontrar el menor camino en todos los vertices : 
               for (int ctn = 0; ctn < b; ctn++) {
                    /* Se elige siempre la menor distancia de entre los vértices que no hayan
                   sido procesados en la primera iteración*/
            int menor=menor_distancia(dis, process, b);
            // Cambiar el vértice de NO PROCESADO  a Procesado
            process[menor]=true;
             // Refrescar la distancia de los vértices en adyacencia al seleccionado
                   for (int select = 0; select < b; select++) {
            /*Actualizar vértice seleccionado si es que no ha sido procesado y si cumple que : El peso desde el origen hasta el seleccionado es menor 
                       que entre los vértices actuales */
                       if (!process[select] && grafo[menor][select] !=0 && dis[menor] != Integer.MAX_VALUE && dis[menor]+grafo [menor][select]<dis[select] ) {
                           dis[select]=dis[menor]+grafo[menor][select];
                           
                       }
                   }
                   
        }
        // Imprimir el camino de solución
        ImprimirCamino(dis, b,source);
             
    }
               
     public static void inMatriz(int node1, int node2, int w, int[][] graph) {
        graph[node1][node2]=w;
    }
     
            
        public static void main(String[] args) throws IOException {
            
        
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Ingrese cantidad de vértices: ");
            String vertice=in.readLine();
            //Usamos readLine para obtener la cantidad de vertices del grafo.
            int cantVertices=Integer.parseInt(vertice);
            int[][] graph= new int[cantVertices][cantVertices];
            int resp=1;
            while (resp!= 0) {
                /*Pedir los nodos y su respectivo peso 
                 si el usuario inserta -0 , se acaba el proceso
                */
                System.out.println("Inserte nodos y sus respectivos pesos: ");
               System.out.println(" ");
                
                System.out.println("1er nodo: ");
                int node1=Integer.parseInt(in.readLine());
              System.out.println(" ");
                
                System.out.println("2do nodo: ");
                int node2=Integer.parseInt(in.readLine());
                System.out.println("");
                
                if (node1>graph.length || node2>graph.length) {
                    System.out.println("Nodo inválidado");
                    break;
                }
                System.out.println("Peso entre los nodos: ");
                int w=Integer.parseInt(in.readLine());
                System.out.println(" ");
                inMatriz(node1,node2,w,graph);
                inMatriz(node2,node1,w,graph);
                System.out.println("Finalizar = 0 , Continuar 1 : ");
                String inResp=in.readLine();
                resp=Integer.parseInt(inResp);
                
                
                /*if (inResp.equals("1")) {
                    resp=1;
                }else{
                    resp=Integer.parseInt(inResp);
                }*/
            }
            
               System.out.println("");
        //Se imprime la matriz de adyacencia 
        System.out.println("╒▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬  ╗");
        System.out.println("Matriz de adyacencia");
        System.out.println("╘▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ╝");

        
        for (int x = 0; x < graph.length; x++) {
            for (int y = 0; y < graph[x].length; y++) {
                System.out.print("├  " + graph[x][y] + "  ┤");
            }
            System.out.println(" ");
        }
        System.out.println("╒▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ ╗");
        System.out.print("Ingrese el nodo origen : ");
        int source = Integer.parseInt(in.readLine());
        
        System.out.println("╘▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ ╝");
        //Inicializar el tiempo de ejecución del programa con la variable Start
        long Start = System.nanoTime();
        Runtime runtime = Runtime.getRuntime();
        NewClass t = new NewClass();
        t.alg_dijkstra(graph, source);
       
        //Inicializar el tiempo final de ejecución del programa con la variable END
        long End = System.nanoTime();
        //cálculo para pasar de minutos a milisegundos 
        long timeexe = (End - Start);
        System.out.println("");
        //imprimir el tiempo de ejecución del programa 
        System.out.println("Tiempo de ejecución del programa en nanosegundos: " + timeexe);
        
        
        System.out.println("Memoria usada: "+ (runtime.totalMemory()-runtime.freeMemory())+"bytes");
        }
}
       
